//***********************************************************
//
//	Name: Mackenzie Schnaekel
//
//	Date: April 10, 2017
//	
//	Description: This is the main for the checkers game
//
//***********************************************************

#include<iostream>
#include"checkers.h"

using namespace std;
using namespace main_savitch_14;

int main()
{
	checkers Mine;
	Mine.play();
}



